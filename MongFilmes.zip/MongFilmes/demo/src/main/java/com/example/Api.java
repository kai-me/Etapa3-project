package com.example;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class Api {
    private final HttpClient httpClient = HttpClients.createDefault();
    private static final String OMDB_API_URL = "http://www.omdbapi.com/";
    private static final String API_KEY = "5ff7c844";

    public String fetchDataFromOmdb(String NomeFilme) throws Exception {
        String apiUrl = OMDB_API_URL + "?t=" + NomeFilme + "&apikey=" + API_KEY;
        HttpGet request = new HttpGet(apiUrl);

        try {
            HttpResponse response = httpClient.execute(request);
            if (response.getStatusLine().getStatusCode() == 200) {
                return EntityUtils.toString(response.getEntity());
            } else {
                throw new Exception("Erro ao fazer a solicitação à API OMDB: " + response.getStatusLine().getReasonPhrase());
            }
        } finally {
            request.releaseConnection();
        }
    }
}
