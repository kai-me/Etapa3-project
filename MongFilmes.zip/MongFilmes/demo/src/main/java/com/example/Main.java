package com.example;

public class Main {
    public static void main(String[] args) {
        try {
            Api omdbApiClient = new Api();
            String jsonData = omdbApiClient.fetchDataFromOmdb("The Matrix");

            mongconec mongoDBClient = new mongconec();
            mongoDBClient.saveDataToMongoDB(jsonData);

            mongoDBClient.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
