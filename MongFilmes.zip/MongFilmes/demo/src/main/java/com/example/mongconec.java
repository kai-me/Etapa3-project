package com.example;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class mongconec {
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;

    public mongconec() {
        
        this.mongoClient = new MongoClient("localhost", 27017);
        this.database = mongoClient.getDatabase("Filmes");
        this.collection = database.getCollection("Dados Filmes");
    }

    public void saveDataToMongoDB(String jsonData) {
        
        Document document = Document.parse(jsonData);
        collection.insertOne(document);
    }

    public void close() {
        
        mongoClient.close();
    }
}

